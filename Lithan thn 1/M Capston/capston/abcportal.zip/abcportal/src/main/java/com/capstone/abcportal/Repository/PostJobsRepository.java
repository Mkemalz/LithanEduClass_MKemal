package com.capstone.abcportal.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.capstone.abcportal.model.PostJobs;

@Repository
public interface PostJobsRepository extends JpaRepository<PostJobs, Long> {
    // Custom query methods or other repository-specific code can go here
}
