package com.capstone.abcportal.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstone.abcportal.Repository.PostJobsRepository;
import com.capstone.abcportal.model.PostJobs;
import com.capstone.abcportal.Repository.PostJobsRepository;

@Service
@Transactional
public class PostJobsService {

    @Autowired
    PostJobsRepository postJobRepository;

    public PostJobs addPostJob(PostJobs postJob) {
        return postJobRepository.save(postJob);
    }

    public List<PostJobs> getAllPostJobs() {
        return postJobRepository.findAll();
    }
    
    public PostJobs getJobById(Long jobId) {
        return postJobRepository.findById(jobId).orElse(null);
    }
}
