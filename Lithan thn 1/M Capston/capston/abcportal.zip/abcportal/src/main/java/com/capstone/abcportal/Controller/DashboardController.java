package com.capstone.abcportal.Controller;

import com.capstone.abcportal.Repository.UserDetailsRepository;
import com.capstone.abcportal.model.ApplyJobs.ApplyJob;
import com.capstone.abcportal.model.BulkEmail;
import com.capstone.abcportal.model.Educations;
import com.capstone.abcportal.model.Experiences;
import com.capstone.abcportal.model.PostJobs;
import com.capstone.abcportal.model.ThreadPost;
import com.capstone.abcportal.model.UserDetails;
import com.capstone.abcportal.service.ApplyService;

import com.capstone.abcportal.service.EducationsService;
import com.capstone.abcportal.service.ExperiencesService;
import com.capstone.abcportal.service.PostJobsService;
import com.capstone.abcportal.service.ThreadService;
import com.capstone.abcportal.service.UserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
public class DashboardController {
	
	 @Autowired
	    private ApplyService applyJobService;
	 
	 @Autowired
	    private UserDetailsService userDetailsService;
	
    @Autowired
    UserDetailsService ud;

    @Autowired
    ExperiencesService experience_service;
    
    @Autowired
    PostJobsService postJobsService;

    @Autowired
    EducationsService education_service;
    
    @Autowired
    private ThreadService threadService;

    @Autowired
    private UserDetailsRepository userDetailsRepository;

    @RequestMapping(value="/dash2") // profile overview
    public ModelAndView dashboard(HttpSession session, Model model) throws Exception {
        try {
            this.setModel(model, session);
            return new ModelAndView("dash2");
        } catch (Exception e) {
            System.out.println(e);
            String msg = "Login required";
            model.addAttribute("message", msg);
            return new ModelAndView("login");
        }
    }
    
    

    @RequestMapping(value = "/profile")
    public ModelAndView profile(HttpSession session, Model model) {
        try {
            setModel(model, session);
            return new ModelAndView("profile");
        } catch (Exception e) {
            System.out.println(e);
            String msg = "Login required";
            model.addAttribute("message", msg);
            return new ModelAndView("login");
        }
    }
    
    @RequestMapping(value = "/allJobs")
    public ModelAndView allJobs(HttpSession session, Model model) {
        try {
            setModel(model, session);
            return new ModelAndView("allJobs");
        } catch (Exception e) {
            System.out.println(e);
            String msg = "Login required";
            model.addAttribute("message", msg);
            return new ModelAndView("login");
        }
    }
   
   
    

    //UPDATE PROFILE
    @RequestMapping(value="/update-profile") // update profile GET
    public ModelAndView updateProfile(Model model, HttpSession session) throws Exception {
        try {
            this.setModel(model, session);
            return new ModelAndView("profile");
        } catch (Exception e) {
            System.out.println(e);
            String msg = "Login required";
            model.addAttribute("message", msg);
            return new ModelAndView("login");
        }
    }

    @RequestMapping(value="/update-profile", method = RequestMethod.POST) // update profile POST
    public String up(

            @ModelAttribute("profile") UserDetails userDetails,
            @RequestParam("firstName") String fullname,
            @RequestParam("lastName") String lastName,
            @RequestParam("city") String city,
            @RequestParam("phoneNumber") String phoneNumber,
       
            Model model, HttpSession session) {

        Long userDetailsId = Long.parseLong(String.valueOf(session.getAttribute("userId")));
        ud.updateProfile(userDetailsId, userDetails);

        this.setModel(model, session);

        String msg = "Profile has been updated";
        model.addAttribute("message", msg);
        return "profile";
    }

    //ADD EDUCATION
    @RequestMapping(value="/add_education", method = RequestMethod.POST) // update profile POST
    public String addEducation(

            @RequestParam("intitutionName") String intitutionName,
            @RequestParam("startDateED") String startDateED,
            @RequestParam("endDateED") String endDateED,
            @RequestParam("educationName") String educationName,
            Educations educations,
            Model model, HttpSession session) {

        Long userDetailsId = Long.parseLong(String.valueOf(session.getAttribute("userId")));

        if(intitutionName.equals("") || startDateED.equals("") || endDateED.equals("") || educationName.equals("")) {
            System.out.println("Educations Empty");
        } else {
            // exs.updateExperiences(String.valueOf(userDetailsId), experiences);
            educations.setIntitutionName(intitutionName);
            educations.setStartDate(startDateED);
            educations.setEndDate(endDateED);
            educations.setEducationName(educationName);
            educations.setUserDetailsId(Long.valueOf(userDetailsId));
            education_service.addEducations(educations);
        }

        String msg = "Profile has been updated";
        model.addAttribute("message", msg);
//		return "profile";
        return "redirect:/profile";
    }

    //	ADD EXPERIENCE
    @RequestMapping(value="/add_experience", method = RequestMethod.POST) // update profile POST
    public String addExperience(

            @RequestParam("position") String position,
            @RequestParam("companyName") String companyName,
            @RequestParam("startDate") String startDate,
            @RequestParam("endDate") String endDate,
            Experiences experiences,
            Model model, HttpSession session) {

        Long userDetailsId = Long.parseLong(String.valueOf(session.getAttribute("userId")));

        if  (companyName.equals("") || position.equals("") || startDate.equals("") || endDate.equals(""))  {
            System.out.println("Experiences Empty");
        } else {

            // exs.updateExperiences(String.valueOf(userDetailsId),	 experiences);
            experiences.setPosition(position);
            experiences.setCompanyName(companyName);
            experiences.setStartDate(startDate);
            experiences.setEndDate(endDate);
            experiences.setUserDetailsId(Long.valueOf(userDetailsId));
            experience_service.addExperiences(experiences);
        }

        String msg = "Profile has been updated";
        model.addAttribute("message", msg);
//		return "profile";
        return "redirect:/profile";
    }
    
    @PostMapping("/create_thread")
    public String createThread(@ModelAttribute ThreadPost forumThread, @RequestParam(value = "imageFile", required = false) MultipartFile imageFile,
                               @RequestParam("postBody") String postBody,
                               Model model, HttpSession session) {

        Long userId = (Long) session.getAttribute("userId");

        forumThread.setBody(postBody);

        try {
            if (imageFile != null && !imageFile.isEmpty()) {
                forumThread.setImg(imageFile.getBytes());
            }

            UserDetails userDetails = ud.getDetailsById(userId);
            forumThread.setUserDetails(userDetails);

            threadService.addThread(forumThread);

            String msg = "Thread berhasil dibuat";
            model.addAttribute("message", msg);
        } catch (IOException e) {
            String errorMsg = "Terjadi kesalahan saat mengunggah gambar.";
            model.addAttribute("error", errorMsg);
        }

        return "redirect:/dash2";
    }

    
    @GetMapping("/posts")
    public String showAllPosts(Model model) {
        List<ThreadPost> posts = threadService.getAllThread();
        model.addAttribute("posts", posts);

        return "post_list"; // Ganti dengan nama halaman JSP yang sesuai
    }
    
    @PostMapping("/apply_job")
    public String applyJob(@RequestParam("jobId") Long jobId, HttpSession session, RedirectAttributes redirectAttributes) {
        try {
            UserDetails userDetails = userDetailsService.getDetailsById((Long) session.getAttribute("userId"));
            PostJobs job = postJobsService.getJobById(jobId);

            if (userDetails != null && job != null) {
                ApplyJob applyJob = new ApplyJob();
                applyJob.setUserDetails(userDetails);
                applyJob.setJob(job);
                applyJob.setCreatedAt(LocalDateTime.now());

                applyJobService.saveApplyJob(applyJob);

                redirectAttributes.addFlashAttribute("message", "Job applied successfully!");
            } else {
                redirectAttributes.addFlashAttribute("error", "Error applying job.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error applying job.");
        }

        return "redirect:/allJobs";
    }
    


    
    
    private void setModel(Model model, HttpSession session) {
        String userId = String.valueOf(session.getAttribute("userId"));
        String[] userDetails = ud.getDetailsById(userId).replaceAll("null", "-").split(",");
        String udID = userDetails[0];

        model.addAttribute("f", userDetails[1].charAt(0));
        model.addAttribute("l", userDetails[2].charAt(0));

        model.addAttribute("firstName", userDetails[1]);
        model.addAttribute("lastName", userDetails[2]);

        model.addAttribute("fullName", userDetails[1] + " " + userDetails[2]);
        model.addAttribute("city", userDetails[3]);
        model.addAttribute("phoneNumber", userDetails[4]);


//		// experiences
        model.addAttribute("experiences", experience_service.getExperiencesByUserDetailsId(udID)); // Experiences[]
        
//		// educations
        model.addAttribute("educations", education_service.getEducationsByUserDetailsId(udID)); // Educations[]
        
        List<ThreadPost> Post = threadService.getAllThread();
        model.addAttribute("Postthreed", Post);
        
        List<PostJobs> Jobs = postJobsService.getAllPostJobs();
        model.addAttribute("Jobs", Jobs);
    }
    
    
    
    
    
    
    
    
}
