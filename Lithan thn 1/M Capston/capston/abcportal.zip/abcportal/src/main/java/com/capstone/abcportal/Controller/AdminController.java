package com.capstone.abcportal.Controller;

import com.capstone.abcportal.helper.Profile;
import com.capstone.abcportal.model.BulkEmail;
import com.capstone.abcportal.model.Educations;
import com.capstone.abcportal.model.Experiences;
import com.capstone.abcportal.model.PostJobs;
import com.capstone.abcportal.model.ThreadPost;
import com.capstone.abcportal.model.UserDetails;
import com.capstone.abcportal.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
public class AdminController {
	@Autowired
	UsersService us;

	@Autowired
	UserDetailsService ud;
	
	@Autowired
	PostJobsService job;

	@Autowired
	EducationsService eds;

	@Autowired
	ExperiencesService exs;

	@Autowired
	BulkEmailService bs;

	@Autowired
	private PostJobsService postJobService;

	@Autowired
	private UserDetailsService userDetailsService;

	@RequestMapping(value = "/admin")
	public ModelAndView index(Model model, HttpSession session) {
		String name = ud.getDetailsById(session.getAttribute("userId").toString()).split(",")[1];
		model.addAttribute("adminName", name);
		
		
		  List<PostJobs> Post = postJobService.getAllPostJobs();
		  model.addAttribute("PostJobsList", Post);
		 
		
		return new ModelAndView("indexAdmin");
	}

//    Send Bulk Email

	@RequestMapping(value = "/send-bulk")
	public ModelAndView sendBulk(@ModelAttribute("sendBulk") BulkEmail bulkEmail, HttpSession session) {
		return new ModelAndView("send-bulk");
	}

	@RequestMapping(value = "/send-bulk", method = RequestMethod.POST)
	public String sb(@ModelAttribute("sendBulk") BulkEmail bulkEmail, HttpSession session) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();

		bulkEmail.setSendBy("1");
		bulkEmail.setCreatedAt(dtf.format(now));
		bs.sendEmail(bulkEmail.getEmailSubject(), bulkEmail.getEmailBody(), null);

		bs.saveToDB(bulkEmail);
		return "redirect:/admin";
	}

	@RequestMapping(value = "/all-users")
	public ModelAndView allUsers(Model model, HttpSession session) {
		List<UserDetails> users = ud.getAllUserDetails();
		String cd = null;

		System.out.println("OK " + cd);
		model.addAttribute("users", users);
//		model.addAttribute("cities", cr.findAll());
		return new ModelAndView("all-users");
	}

	@RequestMapping(value = "/delete/{id}")
	public String deleteUserById(@PathVariable("id") Long id, Model model) {
		boolean isDeleted = us.deleteUserById(id);
		if (isDeleted) {
			model.addAttribute("err", "Cannot delete this user");
		}

		return "redirect:/all-users";
	}
	
	
	@RequestMapping(value = "/jobadmin")
	public ModelAndView jobadmin(Model model, HttpSession session) {
		List<UserDetails> users = ud.getAllUserDetails();
		String cd = null;

		System.out.println("OK " + cd);
		model.addAttribute("users", users);
//		model.addAttribute("cities", cr.findAll());
		return new ModelAndView("jobadmin");
	}

	@RequestMapping(value = "/deletejob/{id}")
	public String deletejobUserById(@PathVariable("id") Long id, Model model) {
		boolean isDeleted = us.deleteUserById(id);
		if (isDeleted) {
			model.addAttribute("err", "Cannot delete this user");
		}

		return "redirect:/jobadmin";
	}

	@RequestMapping(value = "/profile/{id}")
	public ModelAndView profile(@PathVariable("id") Long id, Model model, HttpSession session, Profile profile) {
		UserDetails userDetails = ud.getDetailsById(id);
		List<Experiences> experiences = exs.getExperiencesByUserDetailsId(userDetails.getUserDetailsId().toString());
		List<Educations> educations = eds.getEducationsByUserDetailsId(userDetails.getUserDetailsId().toString());

		profile.setId(userDetails.getUserDetailsId());
		profile.setFirstName(userDetails.getFirstName());
		profile.setLastName(userDetails.getLastName());
		profile.setFullName(userDetails.getFirstName() + " " + userDetails.getLastName());

		profile.setPhoneNumber(userDetails.getPhoneNumber());
		profile.setCity(userDetails.getCity());
		profile.setEx(experiences);
		profile.setEd(educations);

		this.setModel(profile, model, session);
		return new ModelAndView("userprofile");
	}

	@PostMapping("/create_postjob")
	public String createPostJob(@ModelAttribute PostJobs postJob,
			@RequestParam(value = "imageFile", required = false) MultipartFile imageFile,
			@RequestParam("postBody") String postBody, Model model, HttpSession session) {

		Long userId = (Long) session.getAttribute("userId");

		postJob.setBody(postBody);

		try {
			if (imageFile != null && !imageFile.isEmpty()) {
				postJob.setImg(imageFile.getBytes());
			}

			UserDetails userDetails = userDetailsService.getDetailsById(userId);
			postJob.setUserDetails(userDetails);

			postJobService.addPostJob(postJob);

			String msg = "Post job berhasil dibuat";
			model.addAttribute("message", msg);
		} catch (IOException e) {
			String errorMsg = "Terjadi kesalahan saat mengunggah gambar.";
			model.addAttribute("error", errorMsg);
		}

		return "redirect:/allJobs";
	}

	/*
	 * @GetMapping("/job-list") public String jobList(Model model) { List<PostJobs>
	 * postJobs = postJobService.getAllPostJobs(); // Retrieve jobs from the service
	 * model.addAttribute("postJobs", postJobs); return "job_list"; // Return the
	 * name of your Thymeleaf template }
	 */

	@RequestMapping(value = "profile/update-profile", method = RequestMethod.POST) // update profile POST
	public String up(@ModelAttribute("profile") UserDetails userDetails, Model model, HttpSession session) {
		Long userDetailsId = userDetails.getUserDetailsId();
		ud.updateProfile(userDetailsId, userDetails);
		return "redirect:../all-users";
	}

	private void setModel(Profile profile, Model model, HttpSession session) {
		model.addAttribute("id", profile.getId());
		model.addAttribute("f", profile.getFirstName().charAt(0));
		model.addAttribute("l", profile.getLastName().charAt(0));

		model.addAttribute("firstName", profile.getFirstName());
		model.addAttribute("lastName", profile.getLastName());

		model.addAttribute("firstName", profile.getFirstName());
		model.addAttribute("lastName", profile.getLastName());

		model.addAttribute("fullName", profile.getFullName());
		model.addAttribute("phoneNumber", profile.getPhoneNumber());
		model.addAttribute("City", profile.getCity());

		// experiences
		model.addAttribute("ex", profile.getEx()); // Experiences[]

		// educations
		model.addAttribute("ed", profile.getEd()); // Educations[]
		
		/* model.addAttribute("job", profile.getJob()); */
	}
}
