package com.capstone.abcportal.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capstone.abcportal.model.ThreadPost;

@Repository
public interface ThreadRepository extends JpaRepository<ThreadPost, Long> {
	 @Query(value = "SELECT * FROM forum_threads WHERE user_details_id = :udID", nativeQuery = true)
	    public List<ThreadPost> getThreadsByUserDetailsId(@Param("udID") String udID);

}
