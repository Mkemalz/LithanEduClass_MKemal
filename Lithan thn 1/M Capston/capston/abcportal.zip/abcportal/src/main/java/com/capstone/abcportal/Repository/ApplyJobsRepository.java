package com.capstone.abcportal.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstone.abcportal.model.ApplyJobs.ApplyJob;

@Repository
public interface ApplyJobsRepository extends JpaRepository<ApplyJob, Long> {
    // Custom query methods if needed
}
