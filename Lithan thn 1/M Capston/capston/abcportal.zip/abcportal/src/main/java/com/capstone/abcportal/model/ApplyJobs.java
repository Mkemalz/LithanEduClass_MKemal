package com.capstone.abcportal.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

public class ApplyJobs {
	
	@Entity
	@Table(name = "apply_job")
	public class ApplyJob {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "apply_job_id")
	    private Long applyJobId;

	    @ManyToOne
	    @JoinColumn(name = "user_details_id") // Menggunakan kolom user_details_id sebagai foreign key
	    private UserDetails userDetails;

	    @ManyToOne
	    @JoinColumn(name = "job_id") // Menggunakan kolom jobs_id sebagai foreign key
	    private PostJobs job;

	    @Column(name = "created_at")
	    private LocalDateTime createdAt;
	     
	    
	  



		public void setUserDetails(UserDetails userDetails) {
			this.userDetails = userDetails;
		}



		public PostJobs getJob() {
			return job;
		}



		public void setJob(PostJobs job) {
			this.job = job;
		}



		public LocalDateTime getCreatedAt() {
			return createdAt;
		}



		public void setCreatedAt(LocalDateTime createdAt) {
			this.createdAt = createdAt;
		}



		public void setApplyJobId(Long applyJobId) {
			this.applyJobId = applyJobId;
		}



		public ApplyJob(Long applyJobId, UserDetails userDetails, PostJobs job, LocalDateTime createdAt) {
			super();
			this.applyJobId = applyJobId;
			this.userDetails = userDetails;
			this.job = job;
			this.createdAt = createdAt;
		}



		public ApplyJob() {}

}
}
