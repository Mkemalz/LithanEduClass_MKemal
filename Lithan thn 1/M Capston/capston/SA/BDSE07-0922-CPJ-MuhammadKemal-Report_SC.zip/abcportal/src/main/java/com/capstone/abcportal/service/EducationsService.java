package com.capstone.abcportal.service;

import com.capstone.abcportal.model.Educations;
import com.capstone.abcportal.Repository.EducationsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class EducationsService {
    @Autowired
    EducationsRepository repo;

    public Educations addEducations(Educations ed) {
        return repo.save(ed);
    }

    public List<Educations> getEducationsByUserDetailsId(String udID) {
        return repo.getEducationsByUserDetailsId(udID);
    }
}
