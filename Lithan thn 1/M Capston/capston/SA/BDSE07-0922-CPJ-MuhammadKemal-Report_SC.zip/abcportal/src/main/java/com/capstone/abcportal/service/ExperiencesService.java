package com.capstone.abcportal.service;

import com.capstone.abcportal.model.Experiences;
import com.capstone.abcportal.Repository.ExperiencesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class ExperiencesService {
    @Autowired
    ExperiencesRepository repo;

    public Experiences addExperiences(Experiences ex) {
        return repo.save(ex);
    }

    public List<Experiences> getExperiencesByUserDetailsId(String udID) {
        return repo.getExperiencesByUserDetailsId(udID);
    }

}
