package com.capstone.abcportal.service;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstone.abcportal.model.ThreadPost;
import com.capstone.abcportal.Repository.ThreadRepository;

@Service
@Transactional
public class ThreadService {
	
	@Autowired
	ThreadRepository threadRepo;
	
	public ThreadPost addThread (ThreadPost add) {
		return threadRepo.save(add);
	}
	
	public List<ThreadPost> getAllThread(){
		 return threadRepo.findAll();
		}

}