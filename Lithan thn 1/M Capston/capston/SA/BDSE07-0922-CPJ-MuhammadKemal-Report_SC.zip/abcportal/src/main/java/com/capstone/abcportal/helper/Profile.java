package com.capstone.abcportal.helper;

import java.util.List;

import com.capstone.abcportal.model.Educations;
import com.capstone.abcportal.model.Experiences;

public class Profile {
	private Long id;
	private String firstName;
	private String lastName;
	private String fullName;
	private String phoneNumber;
	private String city;
	
	public Profile(Long id, String firstName, String lastName, String fullName, String phoneNumber, String city,
			List<Experiences> ex, List<Educations> ed) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.fullName = fullName;
		this.phoneNumber = phoneNumber;
		this.city = city;
		this.ex = ex;
		this.ed = ed;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public List<Experiences> getEx() {
		return ex;
	}
	public void setEx(List<Experiences> ex) {
		this.ex = ex;
	}
	public List<Educations> getEd() {
		return ed;
	}
	public void setEd(List<Educations> ed) {
		this.ed = ed;
	}
	private List<Experiences> ex;	
	private List<Educations> ed;

	
}
