package com.capstone.abcportal.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.capstone.abcportal.helper.Base64Util;
@Entity
@Table(name = "threadpost")

public class ThreadPost {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "thread_id")
	private Long threadId;
	
	@ManyToOne
    @JoinColumn(name = "user_details_id") // Nama kolom yang akan digunakan untuk menyimpan kunci asing
    private UserDetails userDetails;
	
	@Column(name = "body")
	private String body;
	
	@Column(name = "created_at")
	private String createdAt;
	
	@Lob
	@Column(name = "img")
	private byte[] img;
	
	@Column(name = "title")
	private String title;

	
	public String getPostImageDataBase64(){
		
		return Base64Util.encodeBase64(this.img);
	}
	
	
	public ThreadPost(Long threadId, UserDetails userDetails, String body, String createdAt, byte[] img, String title) {
		super();
		this.threadId = threadId;
		this.userDetails = userDetails;
		this.body = body;
		this.createdAt = createdAt;
		this.img = img;
		this.title = title;
	}

	public Long getThreadId() {
		return threadId;
	}

	public void setThreadId(Long threadId) {
		this.threadId = threadId;
	}

	public UserDetails getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public byte[] getImg() {
		return img;
	}

	public void setImg(byte[] img) {
		this.img = img;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	
	
	

	

	public ThreadPost(){}
	
	public String getPostImagesDataBase64() {
    	return Base64Util.encodeBase64(this.img);
    }
}
