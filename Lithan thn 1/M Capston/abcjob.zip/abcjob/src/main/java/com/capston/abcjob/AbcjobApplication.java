package com.capston.abcjob;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbcjobApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbcjobApplication.class, args);
	}

}
