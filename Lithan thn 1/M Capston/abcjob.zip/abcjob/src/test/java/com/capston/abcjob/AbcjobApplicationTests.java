package com.capston.abcjob;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbcjobApplicationTests {

	@Test
	void contextLoads() {
	}

}
