package com.example.mow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MowApp {

    public static void main(String[] args) {
        SpringApplication.run(MowApp.class, args);
    }

}
