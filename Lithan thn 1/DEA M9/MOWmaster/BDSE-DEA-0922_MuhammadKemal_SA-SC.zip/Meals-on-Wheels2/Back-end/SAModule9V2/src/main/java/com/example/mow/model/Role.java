package com.example.mow.model;

public class Role {
    public static final String ADMIN = "ADMIN";
    public static final String PARTNER = "PARTNER";
    public static final String CAREGIVER = "CAREGIVER";
    public static final String MEMBER = "MEMBER";
    public static final String DONOR = "DONOR";
    public static final String VOLUNTEER = "VOLUNTEER";
}

