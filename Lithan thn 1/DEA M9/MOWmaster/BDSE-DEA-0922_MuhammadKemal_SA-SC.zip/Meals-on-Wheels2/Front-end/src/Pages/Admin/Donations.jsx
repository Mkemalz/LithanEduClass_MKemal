import Donate from "../../components/Admin/DonateAdmin";

const Donations = () => {
    return ( 
        <div>
            <Donate />
        </div>
     );
}
 
export default Donations;