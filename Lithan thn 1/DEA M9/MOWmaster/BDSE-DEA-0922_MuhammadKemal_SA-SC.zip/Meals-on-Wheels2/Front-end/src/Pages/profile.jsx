import StickyHeader from "../components/Navbar";

const profileMember = () => {
    
    return ( 

        <StickyHeader />
     );
}
 
export default profileMember;