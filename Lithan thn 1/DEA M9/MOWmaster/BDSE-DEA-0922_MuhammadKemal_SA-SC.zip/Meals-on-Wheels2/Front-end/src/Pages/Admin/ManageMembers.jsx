import MemberAdmin from "../../components/Admin/MemberAdmin";

const ManageMembers = () => {
    return ( 
        <div>
            <MemberAdmin/>
        </div>
     );
}
 
export default ManageMembers;