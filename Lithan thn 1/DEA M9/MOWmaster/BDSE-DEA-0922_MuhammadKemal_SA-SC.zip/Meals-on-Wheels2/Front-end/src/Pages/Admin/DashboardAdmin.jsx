import AdminDashboard from "../../components/Admin/AdminDash";

const DashboardAdmin = () => {
  return (
    <div>
      <AdminDashboard />
    </div>
  );
};

export default DashboardAdmin;
