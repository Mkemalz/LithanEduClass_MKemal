import OrderManage from "../../components/Admin/OrderManage";

const MangeOrders = () => {
    return ( 
        <div>
            <OrderManage/>
        </div>
     );
}
 
export default MangeOrders;