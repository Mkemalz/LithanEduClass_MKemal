import DriverManage from "../../components/Admin/DriverManage";

const ManageDriver = () => {
    return ( 
        <div>
            <DriverManage />
        </div>
     );
}
 
export default ManageDriver;