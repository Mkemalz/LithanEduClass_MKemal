import MealsManage from "../../components/Admin/MealsManage";

const ManageMeals = () => {
    return ( 
        <div>
            <MealsManage />
        </div>
     );
}
 
export default ManageMeals;