package com.summative.mealsonwheels.Entity.constrant;

public enum MealsStatus {
    PENDING, PROCESS, READY_TO_DELIVER
}
