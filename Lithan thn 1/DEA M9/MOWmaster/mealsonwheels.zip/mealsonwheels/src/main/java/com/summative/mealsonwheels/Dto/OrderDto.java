package com.summative.mealsonwheels.Dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;
import com.summative.mealsonwheels.Entity.Meals;
import com.summative.mealsonwheels.Entity.Partner;
import com.summative.mealsonwheels.Entity.UserAppDetails;

// @Data
// @Builder
// @AllArgsConstructor
// @NoArgsConstructor
// public class OrderDto {

//     private Long orderId;
//     private Date datetime;
//     private Date updated_at;
//     private String orderStatus;
//     private String feedback;


//     private Meals meals;
//     private Partner partner;
//     private Driver driver;
//     private UserAppDetails member;
// }
