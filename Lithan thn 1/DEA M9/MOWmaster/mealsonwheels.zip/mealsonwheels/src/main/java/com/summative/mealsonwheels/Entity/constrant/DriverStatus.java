package com.summative.mealsonwheels.Entity.constrant;

public enum DriverStatus {
    AVAILABLE, UNAVAILABLE
}
