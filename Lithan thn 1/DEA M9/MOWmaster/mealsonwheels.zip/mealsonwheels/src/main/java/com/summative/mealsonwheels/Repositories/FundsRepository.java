package com.summative.mealsonwheels.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import com.summative.mealsonwheels.Entity.Funds;




public interface FundsRepository extends JpaRepository<Funds, Long> {
    
    

}
