package com.summative.mealsonwheels.Entity.constrant;

public enum TokenType {
    BEARER
}
