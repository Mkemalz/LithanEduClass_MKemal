package com.summative.mealsonwheels.Entity.constrant;

public enum DeliveryStatus {
    PENDING, TAKE_MEALS, ON_THE_WAY, DELIVERED
}
