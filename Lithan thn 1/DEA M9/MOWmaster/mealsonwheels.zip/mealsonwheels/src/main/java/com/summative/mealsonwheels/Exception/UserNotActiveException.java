package com.summative.mealsonwheels.Exception;

public class UserNotActiveException extends RuntimeException {
    

    public UserNotActiveException(String message){
        super(message);
    }

}
