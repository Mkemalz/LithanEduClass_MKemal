package com.summative.mealsonwheels.Entity;

public enum UserRole {
    MEMBER, DRIVER, PARTNER, ADMIN, VOLUNTEER, DONOR
}
