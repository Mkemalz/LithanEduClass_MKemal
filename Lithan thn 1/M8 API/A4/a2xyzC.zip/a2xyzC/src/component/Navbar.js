import { NavLink } from "react-router-dom";
// import Logo from '../component/images/logo512.png'
const Navbar = () => {
    return ( 
      <nav class="navbar">
  <div class="container">
    <div class="navbar-brand">
      <span class="logo-text">XyzCars</span>
    </div>
    <div class="navbar-menu">
      <ul>
        
        <li>
        <a href="/home" class="navbar-link">Home</a>
          </li>
      
        
        <li>
          <a href="/carpost" class="navbar-link">Post Cars</a>
          </li>

          <li>
          <a href="/contact" class="navbar-link">Contact</a>
          </li>
       
      </ul>
    </div>
    <div class="search-bar">
      <input type="text" class="search-input" placeholder="Search..."/>
      <button class="search-button"><i class="fas fa-search"></i></button>
    </div>
  </div>
</nav>


    
     );
}


 
export default Navbar;