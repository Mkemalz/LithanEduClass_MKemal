import Car from '../images/hondaanjay.jpg'
import { baseURL } from "../utils/const";
import { useState, useEffect } from "react";
import axios from "axios";
const Card = () => {

    const [cars, setCars] = useState(null);

  useEffect(() => {
    axios.get(baseURL + "/car/all_cars").then((response) => {
      setCars(response.data);
    });
  }, []);

  if (!cars) return null;

    return (

<>
        <div className="list-car-container">
        {cars.map((value, index) => (
          <div className="card">
            <div className="card-image">
              <img src={Car} alt="" />
            </div>
            <div className="category"> XYZ Cars </div>
            <div className="heading">
              {value.model}
              <div className="price">
                <h5>
                  ${value.price} <small>(Negotiable)</small>
                </h5>
              </div>
              <div className="card-footer">
                <a className="card-button" href={"/cardetail/" + value.id}>
                  See Car Details
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>

      kemal@2023
    </> 
    );
}

export default Card;