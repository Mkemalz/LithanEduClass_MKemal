import Car from '../images/hondaanjay.jpg'
const Cardetails = ({ Cars }) => {
    return (
        <section>
            <div className="container">
                <div className="row">


                    <div className="cardetail-container">
                        <div className="left-container">
                            <img src={Car} alt="" />
                        </div>

                        <div className="right-container">
                            <h1>{Cars.model}</h1>
                            <table>
                                <tr>
                                    <td>Model</td>
                                    <td>{Cars.model}</td>
                                </tr>
                                <tr>
                                    <td>Registration Date : </td>
                                    <td>{Cars.registration}</td>
                                </tr>
                                <tr>
                                    <td>Year : </td>
                                    <td>{Cars.makeCar}</td>
                                </tr>
                                <tr>
                                    <td>Price : </td>
                                    <td>{Cars.price}</td>
                                </tr>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </section>


    );
}

export default Cardetails;