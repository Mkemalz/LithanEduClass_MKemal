import { useState } from "react";
import axios from "axios";
import swal from "sweetalert";

const CardPost = () => {

  const [model, setModel] = useState();
  const [makeCar, setMakeCar] = useState();
  const [price, setPrice] = useState();
  const [registration, setRegistration] = useState();

  const handleSubmit = (e) => {
    e.preventDefault();


    try {
      const response = axios.post("http://localhost:8080/car/PostCar", {
        model: model,
        makeCar: makeCar,
        registration: registration,
        price: price,
      })

      swal("Car Posted Successfully").then(() => {
        window.location.href = "/"
      })


    } catch (error) {
      console.log(error);
      swal(error)
    }

    console.log(makeCar, model, price, registration);
  };


  return (
    <>
      <div className="container mx-auto">
        <div class="cardpost mx-auto">
          <div class="card-title">Post Car</div>

          <form onSubmit={handleSubmit}>
            <div class="formGroup">
              <label for="">Make (Year):</label>
              <input type="text" value={makeCar} onChange={(e) => setMakeCar(e.target.value)} required />
            </div>

            <div class="formGroup">
              <label for="">Model:</label>
              <input type="text" value={model} onChange={(e) => setModel(e.target.value)} required />
            </div>

            <div class="formGroup">
              <label for="">Price ($):</label>
              <input type="text" value={price} onChange={(e) => setPrice(e.target.value)} required />
            </div>

            <div class="formGroup">
              <label for="">Registration Date:</label>
              <input type="date" value={registration} onChange={(e) => setRegistration(e.target.value)} required />
            </div>

            <button type="submit">Post Car</button>
          </form>
        </div>
      </div>

    </>
  );
}

export default CardPost;