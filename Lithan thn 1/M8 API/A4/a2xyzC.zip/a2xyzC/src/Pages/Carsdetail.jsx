import CarDetails from "../component/CarDetails"
import { useParams, useHref } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";
// import Header from "../components/Header";



const CarsDetail = () => {

  const { id } = useParams();
  const href = useHref();

  const [cars, setCars] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:8080/car/car_details/" + id)
      .then((response) => {
        setCars(response.data);
      })
      .catch((err) => {
        window.location.href = "/home";
      });
  }, []);

  if (!cars) return null;

    return ( 
       <div>
        <CarDetails Cars={cars}  />
       </div>
     );
}
 
export default CarsDetail;