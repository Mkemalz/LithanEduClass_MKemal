import CardPost from "../component/CardPost";

const PostCar = () => {
    return ( 
        <CardPost />
     );
}
 
export default PostCar;