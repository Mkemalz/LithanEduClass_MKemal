import { useState } from "react";
import { SendAMessage } from "../service/Service";

const ContactUs = () => {

    const [message, setMessage] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(message);
        SendAMessage(message);
    };
    return (
        <section>
            <div className="container">
                <div className="row">
                    <div class="card3">
                        <h2>Send Your Message</h2>
                        <form onSubmit={handleSubmit}>
                            <textarea class="form-control"
                                id="message"
                                rows="5"
                                value={message}
                                placeholder="Write your message here..."
                                onChange={(e) => setMessage(e.target.value)}
                                required></textarea>
                            <button type="submit">Send Message</button>
                        </form>
                        <p> example@example.com</p>
                        <p>Mobile Phone: +1234567890</p>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default ContactUs;