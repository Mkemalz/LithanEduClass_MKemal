import Card from "../component/Card"

const Home = () => {
    return (
        <Card />
      );
}
 
export default Home;
