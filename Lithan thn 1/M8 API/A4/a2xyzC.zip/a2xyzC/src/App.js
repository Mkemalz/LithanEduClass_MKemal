import './App.css';
import { BrowserRouter as Router, Routes, Route  } from 'react-router-dom';
import Home from './Pages/Home';
import Navbar from './component/Navbar';
import CardPost from './component/CardPost';
import CarsDetail from './Pages/Carsdetail';
import ContactUs from './Pages/ContactUs';


function App() {
  return (
   <>
   <Navbar />
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/home" element={<Home />} />
        <Route path="/carpost" element={<CardPost />} />
        <Route path="/cardetail/:id" element={<CarsDetail />} />
        <Route path="/contact" element={<ContactUs />} />

      </Routes>
    </Router>
   </>
  );
}

export default App;
