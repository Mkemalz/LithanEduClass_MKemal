import { baseURL } from "../utils/const";
import axios from "axios";
import swal from "sweetalert";

export const SendAMessage = (message) => {
    axios
        .post(baseURL + "/messages/Mkemal",{
            text: message,
        })

        .then((response) => {
            successAlert();
        })
        .catch((err) => {
            alert(err);
            console.log(err);
        });
};

const successAlert = () => {
    swal("Mesaage successfully").then(() => {
        window.location.href = "/contact"
      })
};

