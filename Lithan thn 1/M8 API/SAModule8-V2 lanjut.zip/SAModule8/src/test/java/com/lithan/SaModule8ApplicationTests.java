package com.lithan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaModule8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
