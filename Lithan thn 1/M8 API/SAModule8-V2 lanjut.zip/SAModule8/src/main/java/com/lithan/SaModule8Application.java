package com.lithan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaModule8Application {

	public static void main(String[] args) {
		SpringApplication.run(SaModule8Application.class, args);
	}

}
