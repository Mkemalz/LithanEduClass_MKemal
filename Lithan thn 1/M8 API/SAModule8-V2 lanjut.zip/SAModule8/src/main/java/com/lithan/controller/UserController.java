package com.lithan.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lithan.entity.User;
import com.lithan.service.UserServices;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserServices userServices;

	@Autowired
	private AuthenticationManager authenticate;

	@Autowired
	public UserController(AuthenticationManager authenticate) {
		this.authenticate = authenticate;
	}

	@PostMapping("/register")
	public ResponseEntity<RegisterResponse> addUser(@RequestBody User user) {
		
		RegisterResponse response = new RegisterResponse();
		
		try {
			User users = userServices.addUser(user);
			response.setError(null);
			response.setUser(users);
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			response.setError("Email already registered!");
			response.setUser(null);
			return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
		}
		
	}

	 @PostMapping("/login")
	    public ResponseEntity<User> login(@RequestBody User user) {
	        try {
	            Authentication authentication = authenticate.authenticate(
	                    new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword())
	            );
	            SecurityContextHolder.getContext().setAuthentication(authentication);

	            UserDetails userDetails = userServices.loadUserByUsername(user.getEmail());
	            User authenticatedUser = userServices.loadUserByEmail(userDetails.getUsername());

	            return ResponseEntity.ok(authenticatedUser);
	        } catch (Exception e) {
	            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
	        }
	    }

	@GetMapping("/logout")
	public String logout() {
		SecurityContextHolder.clearContext();
		return "Logout Successfully";
	}

	@GetMapping("/test")
	public String testAsep() {
		return "Nge Teh ASU, Bajingan";
	}
}