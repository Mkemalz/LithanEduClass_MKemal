package com.lithan.entity;

public enum EnumUserRole {
	USER, ADMIN
}
